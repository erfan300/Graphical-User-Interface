package uk.ac.aston.oop.javafx.assessed;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import uk.ac.aston.oop.javafx.assessed.model.Database;
import uk.ac.aston.oop.javafx.assessed.model.Video;

public class CreateVideoController {

	@FXML private TextArea commentText;
	@FXML private TextField titleText;
	@FXML private TextField directorText;
	@FXML private Slider playingTimeSlider;
	@FXML private CheckBox ownBox;
	
	private final Database model;
	
	public CreateVideoController(Database model) {
		this.model = model;
	}
	
	@FXML
	public void initialize() {
	
	}
	
	@FXML
	public void createPressed() {
		String title = titleText.getText();
	    String director = directorText.getText();
	    int playingTime = (int) playingTimeSlider.getValue();
	    String comment = commentText.getText();
	    boolean own = ownBox.isSelected();

	    Video video = new Video(title, director, playingTime);
	    video.setComment(comment);
	    video.setOwn(own);
	    
	    model.addItem(video);
	    
	    commentText.getScene().getWindow().hide();
	}
	
	@FXML
	public void cancelPressed() {
	    commentText.getScene().getWindow().hide();
	}

	
}
